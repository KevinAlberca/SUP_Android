package lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Labyrinthe {
    // La liste d'entrées
    private List<Crossing> entries;
    // Le nombre d'entrées
    private final static int NB_ENTRIES = 4;
    //Constructeur
    public Labyrinthe() {
        entries = new ArrayList<>();
        // Création des entrées
        for ( int i = 1 ; i <= NB_ENTRIES ; i++) {
            // Initialisation du tableau de chemin
            List<Integer> path = new ArrayList<Integer>();
            // La première valeure
            path.add(i);
            entries.add(new Crossing(path));
        }
    }
    
    // Retourne une entrée au hasard
    public Crossing getEntry() {
        Collections.shuffle(entries);
        return entries.get(0);
    }
    
}