package lab;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Crossing {
    // La liste de crossings suivants
    private List<Crossing> crossings;
	
	private boolean exit = false;
	// Le chemin du crossing
	private List<Integer> path;
	// Le nombre de crossings suivants maximum
	private static final int NB_MAX_NEXT = 4;
	// La longueur maximum d'un chemin dans le labyrinthe
	private static final int MAX_LENGTH = 10;
	
	public Crossing(List<Integer> path) {
	    this.path = path;
	    // Choix du nombre de crossings suivants
	    int nbCrossings = (int) Math.round(Math.random() * NB_MAX_NEXT);
	    // Si il n'y a pas de crossings suivants, c'est une sortie
	    if (nbCrossings == 0 || path.size() > MAX_LENGTH) {
	        exit = true;
	    //Sinon création des crossings
	    } else {
	        crossings = new ArrayList<Crossing>();
	        // Création de nb_crossings
	        for ( int i = 1 ; i <= nbCrossings ; i++ ) {
	            // Copie du path pour éviter une modification externe par référence
	            List<Integer> next_path = new ArrayList<Integer>(path);
	            next_path.add(i);
	            // Instanciation du Crossing
	            crossings.add(new Crossing(next_path));
	        }
	    }
   	}
	// Retourne True si le crossing est une sortie
	public boolean isExit() {
	    return exit;
	}
	// Retourne le nombre de crosing suivants
	public int getNbCrossings() {
	    return crossings.size();
	}
	// Retourne un crossing en particulier
	public Crossing getCrossing(int i) {
	    return crossings.get(i);
	}
	// Retourne une description du chemin
	public String getPath() {
	    return String.join("-", path.stream().map(Object::toString).collect(Collectors.toList()));
	}
	public String toString() {
		return getPath();
	} 
}