package lab;

import lab.Labyrinthe;
import lab.Crossing;;

public class Character implements Runnable  {
	public String name;
	public Crossing entry;
	
	public Character(String name) {
		this.name = name;
		Labyrinthe lab = new Labyrinthe();
		
		this.entry = lab.getEntry();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		while(true){
			System.out.println(this.name + " is on case " +this.entry);
		}
	}


}
