package main;

import lab.*;
import lab.Character;

public class Main {
	
public static void main(String[] args) {
    Labyrinthe labyrinthe = new Labyrinthe();
    // Insert your code here
    
    Character aventurier = new Character("Aventurier");
    Thread t1 = new Thread(aventurier);
    t1.start();
    
    System.out.println(aventurier.getName() + " entre dans le labyrinthe");
    
    
    // Ex: Crossing c = lab.getEntry();
    }
}