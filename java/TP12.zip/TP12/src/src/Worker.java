package src;

public class Worker {
	public String name;
	public int age;
	public int salary;

	public Worker(String name, int age, int salary) {
		if(age < 0)
			throw new IllegalArgumentException("Age must be positive");
		if(salary < 0)
			throw new IllegalArgumentException("Salaray must be positive");
		
		
		this.name = name;
		this.age = age;
		this.salary = salary;
		
	}

	public String introduceMe() {

		return "Bonjour, je m'appel " + this.name + ", j'ai " + this.age + " ans";
	}

	public int getYearlyWage() {
		return this.salary * 12; 
	}
}
