package tests;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import src.Calculator;
import src.Calculator.Operator;


public class CalculatorTestCase {

	public Calculator c;
	
	@Before
	public void setup() {
		this.c = new Calculator();
	}
	
	@After
	public void deleteCalculator() {
		this.c = null;
	}
	
	@Test
	public void shouldAddNumber() {
		c.operate("2", Operator.ADD);
		c.operate("2", Operator.MULTIPLY);
		
		assertEquals("4", c.getTotal());
	}
	
	@Test
	public void shouldSubstractNumber() {
		c.operate("2", Operator.ADD);
		c.operate("1", Operator.SUBTRACT);
		
		assertEquals("1", c.getTotal());
	}
	
	@Test
	public void shouldMultiply() {
		c.operate("2", Operator.ADD);
		c.operate("8", Operator.MULTIPLY);
		
		assertEquals("16", c.getTotal());
	}
	
	@Test
	public void shouldMultiplyByZero() {
		c.operate("1337", Operator.ADD);
		c.operate("0", Operator.MULTIPLY);
		
		assertEquals("0", c.getTotal());		
	}
	
	@Test
	public void shouldDivide() {
		c.operate("20", Operator.ADD);
		c.operate("2", Operator.DIVIDE);
		
		assertEquals("10", c.getTotal());
	}
	
	@Test
	public void shouldDivideByZero() {
		c.operate("20", Operator.ADD);
		c.operate("0", Operator.DIVIDE);
		
		assertEquals("Infinity", c.getTotal());
	}

}
