package tests;

import static org.junit.Assert.*;
import src.Worker;
import org.junit.Test;


public class WorkerTest {
	

	@Test
	public void introduceWorkerTest() {
		Worker w = new Worker("Toto", 42, 1500);
		assertEquals("Bonjour, je m'appel Toto, j'ai 42 ans", w.introduceMe());
	}
	
	@Test
	public void getYearlyWageTest() {
		Worker w = new Worker("Toto", 42, 1500);
		assertEquals(w.getYearlyWage(), 18000);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void negativeSalaryTest() {
		Worker w = new Worker("Toto", 42, 1500);
		assertTrue("Salary must be positive", w.salary > 0);
		

		Worker w1 = new Worker("YOLO", -1, -1);
		assertTrue("Age must be positive !", w1.salary > 0);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void negativeAgeTest() {
		Worker w = new Worker("Toto", 42, 1500);
		assertTrue("age must be positive", w.age > 0);
		
		Worker w1 = new Worker("YOLO", -1, 0);
		assertTrue("Age must be positive !", w1.age > 0);
		
	}
}