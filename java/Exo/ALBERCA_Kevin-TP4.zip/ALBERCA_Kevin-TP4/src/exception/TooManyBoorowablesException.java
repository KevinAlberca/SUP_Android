package exception;

public class TooManyBoorowablesException extends java.lang.Exception {

	private static final long serialVersionUID = -5491925956133348504L;
	
	public TooManyBoorowablesException(String message) {
		super(message);
	}

}
