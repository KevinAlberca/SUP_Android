package exception;

public class UnavailableException extends Exception {

	private static final long serialVersionUID = 3322838267906845724L;

	public UnavailableException(String message) {
		super(message);
	}
}
