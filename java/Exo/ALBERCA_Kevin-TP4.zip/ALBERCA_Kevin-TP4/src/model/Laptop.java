package model;

public class Laptop extends Hardware implements Borrowable {

	public enum OS {
		LINUX,
		MAC,
		WINDOWS
	}
	
	private OS os;
	private final String brand;
	private boolean borrowed;
	
	public Laptop(String brand, OS os) {
		this.brand = brand;
		this.os = os;
		this.borrowed = false;
	}
	
	@Override
	public boolean isAvailable() {
		return ! isBorrowed();
	}

	@Override
	public String toString() {
		return "laptop '" + brand + "', sous " + os;
	}

	public boolean isBorrowed() {
		return borrowed;
	}

	@Override
	public void setBorrowed(boolean borrowed) {
		this.borrowed = borrowed;
	}

	public OS getOs() {
		return os;
	}

	public String getBrand() {
		return brand;
	}

}
