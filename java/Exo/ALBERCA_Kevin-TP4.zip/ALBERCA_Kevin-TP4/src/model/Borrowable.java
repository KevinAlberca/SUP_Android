package model;



public interface Borrowable {

	public boolean isAvailable();
	
	public void setBorrowed(boolean b);
	
}
