package model;

import java.util.ArrayList;
import java.util.List;

import exception.TooManyBoorowablesException;
import exception.UnavailableException;

public class Library {

	private List<Member> members;
	private List<Document> documents;
	private List<Hardware> hardwares;

	public Library(List<Document> documents, List<Hardware> hardwares) {
		this.documents = documents;
		this.hardwares = hardwares;
		this.members = new ArrayList<Member>();
	}

	public void printContent() {
		
		System.out.println("Documents:");
		
		for (Document doc : documents) {
			System.out.println(" - " + doc);
		}

		System.out.println("Matériel:");
		
		for (Hardware hw : hardwares) {
			System.out.println(" - " + hw);
		}

	}
	
	public void showBorrowed(Member member) {
		
		System.out.println("Elements empruntés par " + member.getName());
		
		for (Borrowable borrowable : member.getBorrowables()) {
			System.out.println(" - " + borrowable);
		}
	}
	
	public void borrow(Member member, Borrowable borrowable) throws UnavailableException, TooManyBoorowablesException {
		System.out.println("Le membre " + member.getName() + " veut emprunter: " + borrowable);
		if (borrowable.isAvailable()) {
			member.addBorrowable(borrowable);
			borrowable.setBorrowed(true);
		} else {
			throw new UnavailableException("L'élément " + borrowable + " est indisponible.");
		}
	}
	
	public void release(Member member, Borrowable borrowable) {
		System.out.println("Le membre " + member.getName() + " rends: " + borrowable);
		member.removeBorrowable(borrowable);
		borrowable.setBorrowed(false);
	}
	
	public List<Document> search(String keyword) {
		
		List<Document> match = new ArrayList<Document>();
		
		for (Document doc : documents ) {
			if (doc.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
				match.add(doc);
			}
		}
		
		return match;
	}

	public List<Member> getMembers() {
		return members;
	}

	public void addMember(Member member) {
		this.members.add(member);
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void addDocument(Document document) {
		this.documents.add(document);
	}
	
	public List<Hardware> getHardwares() {
		return hardwares;
	}

	public void addHardware(Hardware hardware) {
		this.hardwares.add(hardware);
	}

	
}
