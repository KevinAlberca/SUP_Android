package model;

public abstract class Hardware {

	private boolean broken;

	public boolean isBroken() {
		return broken;
	}

	public void setBroken(boolean broken) {
		this.broken = broken;
	}
	
}
