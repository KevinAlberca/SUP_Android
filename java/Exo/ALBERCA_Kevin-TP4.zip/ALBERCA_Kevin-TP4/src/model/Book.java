package model;

public class Book extends Document implements Borrowable {

	private boolean borrowed;
	private String author;
	
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
		this.borrowed = false;
	}

	@Override
	public boolean isAvailable() {
		return ! isBorrowed();
	}
	
	@Override
	public String toString() {
		return "livre '" + title + "' de " + author;
	}

	public boolean isBorrowed() {
		return borrowed;
	}

	@Override
	public void setBorrowed(boolean borrowed) {
		this.borrowed = borrowed;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
}
