package model;

import java.util.ArrayList;
import exception.TooManyBoorowablesException;
import exception.UnavailableException;
import model.Member.Status;

public class MemberThread implements Runnable {
	static Library library;
	private Member member;
	
	public MemberThread(String name,Status status, Library library) {
		this.member= new Member(name,status);
		MemberThread.library = library;
	}
	
	
	@Override
	public void run() {
		while(true){
			double choix=Math.random();
			if(choix<(1.0/3.0)){
				try {
					borrowBook();
				} catch (UnavailableException | TooManyBoorowablesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			else if(choix<2.0/3.0){
				try {
					borrowLaptop();
				} catch (UnavailableException | TooManyBoorowablesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else{
				System.out.println("Rendre un objet");
			}
			
			System.out.println("Running");
		}

	}
	
	synchronized public int borrowBook() throws UnavailableException, TooManyBoorowablesException{
			 ArrayList<Book> books=getBookAvail();
			 if((int) books.size() > 0){
				 MemberThread.library.borrow(member,books.get(0));
				 System.out.println(member.getName() + " a emprunte : " + books.get(0));
				 return 1;
			 }
		 return 0;
	}
	
	public ArrayList<Book> getBookAvail(){
		ArrayList<Book> books=new ArrayList<Book>();
		 Book b=null;
		for(int i=0;i<library.getDocuments().size();i++){
			if(library.getDocuments().get(i).getClass().getName()=="Book"){
				b=(Book) library.getDocuments().get(i);
				System.out.println(library.getDocuments().get(i).getTitle());
				if (b.isAvailable()) { books.add(b); System.out.println("OK");}
			}
			
		}
		return books;
		
	}
	
	synchronized public int borrowLaptop () throws UnavailableException, TooManyBoorowablesException{
			 ArrayList<Laptop> laptop = getLaptopAvail();
			 if((int) laptop.size() > 0){
				 MemberThread.library.borrow(member,laptop.get(0));
				 System.out.println(member.getName() + " a emprunte : " + laptop.get(0));
				 return 1;
			 }
		 return 0;
	}
	
	public ArrayList<Laptop> getLaptopAvail(){
		ArrayList<Laptop> laptop = new ArrayList<Laptop>();
		 Laptop l=null;
		for(int i=0;i<library.getDocuments().size();i++){
			if(library.getDocuments().get(i).getClass().getName()=="Laptop"){
				l=(Laptop) library.getHardwares().get(i);
				System.out.println(library.getDocuments().get(i).getTitle());
				if (l.isAvailable()) { laptop.add(l); System.out.println("OK");}
			}
			
		}
		return laptop;
		
	}
	

}