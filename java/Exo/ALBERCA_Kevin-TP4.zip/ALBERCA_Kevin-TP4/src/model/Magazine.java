package model;

public class Magazine extends Document{

	private String number;
	
	public Magazine(String title, String number) {
		this.title = title;
		this.number = number;
	}

	public String getNumber() {
		return number;
	}

	@Override
	public String toString() {
		return "magazine '" + title + "' numéro: " + number;
	}
	
}
