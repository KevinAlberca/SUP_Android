package model;

public enum OS {
	Windows,
	Mac,
	Linux;
}