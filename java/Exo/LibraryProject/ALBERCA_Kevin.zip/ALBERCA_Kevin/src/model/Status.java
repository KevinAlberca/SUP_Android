package model;

public enum Status{
	Students,
	Teacher;
}
