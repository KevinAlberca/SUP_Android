package model;

public interface Borrowable {
	public boolean isAvailable();
}
