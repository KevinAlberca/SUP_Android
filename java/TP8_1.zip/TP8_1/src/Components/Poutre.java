package Components;

public class Poutre extends Article {
	
	public Poutre(String type, int width, int height, int price) {
		this.type = type;
		this.width = width;
		this.height = height;
		this.price = price;
	}
	
	public int width;
	public int height;
	public String type;
	
	
	public float getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "Poutre [type=" + type + ", width=" + width + ", height=" + height +", prix="+ this.price+"]";
	}
	
	
	
}
