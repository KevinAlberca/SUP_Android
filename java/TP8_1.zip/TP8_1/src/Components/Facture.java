package Components;

import java.util.ArrayList;

public class Facture {
	public ArrayList<Poutre> poutre = new ArrayList<Poutre>();
	public ArrayList<Tournevis> tournevis = new ArrayList<Tournevis>();
	public ArrayList<Lot> lot = new ArrayList<Lot>();

//	public ArrayList<Article> article = new ArrayList<Article>();
	
	public String client;
	public int number;
	
	
	public Facture(int number, String client) {
		this.number = number;
		this.client = client;
	}
	
	public int getTotal() {
		return Lot.totalPrice;
	}


	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "Facture nº" + number + "\n"
				+"client : " + client + " || Total a payer : " + Lot.totalPrice +"€\n"
				+ "----------------------------------------------\n"
				+ this.poutre +" \n"
				+ this.tournevis +" \n"
				+ this.lot +" \n"

				+ "" +" \n";
	}

	public void addLine(Article article) {
		if(article.getClass().getName() == "Poutre") {
			this.tournevis.add((Tournevis) article);
		} else { // FUCK THE LOGIC
			this.poutre.add((Poutre) article);
		}
	}

	public void addLine(Lot lot) {
			this.lot.add(lot);
	}

}
 