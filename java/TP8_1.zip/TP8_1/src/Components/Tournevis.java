package Components;

public class Tournevis extends Article {
	
	public Tournevis(TournevisType type, int price) {
		this.type = type;
		this.price = price;
	}
	
	public enum TournevisType {
		PLAT,
		CRUCIFORME
	}
	
	public TournevisType type;

	public TournevisType getType() {
		return type;
	}

	public void setType(TournevisType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Tournevis [type=" + type + ", price="+ this.price + "]";
	}
	
	
}
