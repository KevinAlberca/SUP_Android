package Components;

//import java.util.ArrayList;

public class Magasin {
	
//	public ArrayList<Poutre> poutres = new ArrayList<Poutre>();
//	public ArrayList<Tournevis> tournevis = new ArrayList<Tournevis>();
	
	
	public void addArticle() {
		
	}

}
