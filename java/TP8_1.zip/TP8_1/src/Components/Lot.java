package Components;

public class Lot {
	
	public Lot(Article article, int quantity, int remise) {
		this.articles = article;
		this.quantity = quantity;
		this.remise = remise;
		Lot.totalPrice = article.price * this.quantity - (article.price * this.quantity * remise /100);
	}

	
	public Article articles;
	public int quantity;
	public int remise;
	
	public static int totalPrice;
	
	
	public Article getArticles() {
		return articles;
	}
	public void setArticles(Article articles) {
		this.articles = articles;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getRemise() {
		return remise;
	}
	public void setRemise(int remise) {
		this.remise = remise;
	}
	public int getTotalPrice() {
		return Lot.totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		Lot.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "Lot [articles=" + articles + ", quantity=" + quantity + ", remise=" + remise + ", totalPrice="
				+ Lot.totalPrice + "]";
	}
	
	
}
