package Main;

import Components.*;
import Components.Tournevis.TournevisType;

public class Main {
	
	public static void main(String args[]) {
	    // Création des instances //
	    ////////////////////////////
	    // Création d'une poutre de 20*10 à 10 euros pièce
	    Article poutre = new Poutre("Pin", 20, 10, 10);
	    // Création d'un tournevis plat à 7 euros pièce
	    Article tournevisPlat = new Tournevis(TournevisType.PLAT, 7);
	    // Création d'un lot dé 20 tournevis avec 10% de remise
	    Lot lotTournevis = new Lot(tournevisPlat, 20, 10);
	    System.out.println(poutre);
	    System.out.println(tournevisPlat);
	    System.out.println(lotTournevis);
	    /////////////////
	    // Facturation //
    	/////////////////
	    Facture facture = new Facture(1, "Mario");
	    facture.addLine(poutre);
	    facture.addLine(lotTournevis);
	    System.out.println("Total : " + facture.getTotal());
	    System.out.println(facture);
	}

}
